package com.dsu.dsu_std

data class ItemsViewModel(val image: Int, val text: String) {
}
